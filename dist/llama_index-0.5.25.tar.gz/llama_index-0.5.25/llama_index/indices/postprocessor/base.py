"""Base postprocessor."""


class BasePostprocessor:
    """Base Postprocessor."""
