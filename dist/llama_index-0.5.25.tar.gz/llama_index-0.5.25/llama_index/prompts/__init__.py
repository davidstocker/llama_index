"""Prompt class."""

from llama_index.prompts.base import Prompt

__all__ = ["Prompt"]
